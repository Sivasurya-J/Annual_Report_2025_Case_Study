from src.models.risk import PipelineMetrics


def test_metrics_schema():

    metrics = PipelineMetrics(
        total_time_seconds=10.5,
        pdf_read_time_seconds=0.5,
        risk_detection_time_seconds=0.1,
        chunking_time_seconds=0.01,
        llm_generation_time_seconds=9.5,
        post_processing_time_seconds=0.2,
        total_pages=190,
        risk_pages=20,
        chunks=5,
        llm_calls=5,
        input_tokens=10000,
        output_tokens=2000,
        total_tokens=12000,
    )

    assert metrics.total_pages == 190
    assert metrics.llm_calls == 5
    assert metrics.total_tokens == 12000