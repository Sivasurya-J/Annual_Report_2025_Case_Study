from pathlib import Path

import pytest

from src.ingestion.pdf_reader import PDFReader


def test_pdf_not_found():

    with pytest.raises(FileNotFoundError):

        PDFReader(
            "does_not_exist.pdf"
        )


def test_pdf_exists():

    pdf_path = Path(
        "data/input/vestas_annual_report.pdf"
    )

    if not pdf_path.exists():

        pytest.skip(
            "Vestas annual report not available."
        )

    reader = PDFReader(
        str(pdf_path)
    )

    pages = reader.extract_pages()

    assert len(pages) > 0

    assert pages[0].page_number == 1

    assert isinstance(
        pages[0].text,
        str
    )