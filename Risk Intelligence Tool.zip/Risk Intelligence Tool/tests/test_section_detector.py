from src.extraction.section_detector import SectionDetector
from src.ingestion.pdf_reader import PageContent


def test_detect_risk_section():

    pages = [
        PageContent(
            page_number=1,
            text="Financial statements and accounting policies"
        ),
        PageContent(
            page_number=2,
            text="Principal Risks and Risk Management"
        ),
        PageContent(
            page_number=3,
            text="Employees and sustainability"
        ),
    ]

    detector = SectionDetector()

    result = detector.detect(
        pages
    )

    assert len(result) == 1

    assert result[0].page_number == 2