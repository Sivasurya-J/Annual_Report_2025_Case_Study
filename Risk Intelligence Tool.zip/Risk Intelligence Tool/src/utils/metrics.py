import time
from dataclasses import dataclass


@dataclass
class MetricsCollector:
    start_time: float = 0.0
    pdf_read_time: float = 0.0
    risk_detection_time: float = 0.0
    chunking_time: float = 0.0
    llm_generation_time: float = 0.0
    post_processing_time: float = 0.0

    total_pages: int = 0
    risk_pages: int = 0
    chunks: int = 0
    llm_calls: int = 0

    input_tokens: int = 0
    output_tokens: int = 0
    total_tokens: int = 0

    def start(self):
        self.start_time = time.perf_counter()

    def elapsed(self, start: float) -> float:
        return time.perf_counter() - start

    def add_tokens(
        self,
        input_tokens: int = 0,
        output_tokens: int = 0,
        total_tokens: int = 0,
    ):
        self.input_tokens += input_tokens
        self.output_tokens += output_tokens
        self.total_tokens += total_tokens

    def finish(self) -> float:
        return time.perf_counter() - self.start_time

    def as_dict(self, total_time: float):
        return {
            "total_time_seconds": round(total_time, 3),
            "pdf_read_time_seconds": round(self.pdf_read_time, 3),
            "risk_detection_time_seconds": round(
                self.risk_detection_time, 3
            ),
            "chunking_time_seconds": round(self.chunking_time, 3),
            "llm_generation_time_seconds": round(
                self.llm_generation_time, 3
            ),
            "post_processing_time_seconds": round(
                self.post_processing_time, 3
            ),
            "total_pages": self.total_pages,
            "risk_pages": self.risk_pages,
            "chunks": self.chunks,
            "llm_calls": self.llm_calls,
            "input_tokens": self.input_tokens,
            "output_tokens": self.output_tokens,
            "total_tokens": self.total_tokens,
        }