from typing import List

from src.ingestion.pdf_reader import PageContent


class RiskChunker:

    def __init__(self, max_chars: int = 12000):
        self.max_chars = max_chars

    def create_chunks(
        self,
        pages: List[PageContent],
    ) -> List[str]:

        chunks = []
        current_chunk = []
        current_length = 0

        for page in pages:

            page_text = (
                f"\n[PAGE {page.page_number}]\n"
                f"{page.text}\n"
            )

            if (
                current_length + len(page_text)
                > self.max_chars
                and current_chunk
            ):
                chunks.append("".join(current_chunk))

                current_chunk = []
                current_length = 0

            current_chunk.append(page_text)
            current_length += len(page_text)

        if current_chunk:
            chunks.append("".join(current_chunk))

        return chunks