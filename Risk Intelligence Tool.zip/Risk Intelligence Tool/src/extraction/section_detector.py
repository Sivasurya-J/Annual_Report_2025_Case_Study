import re
from typing import List

from src.ingestion.pdf_reader import PageContent


class SectionDetector:

    RISK_SECTION_PATTERNS = [
        r"principal risks",
        r"principal risk",
        r"key risks",
        r"key risk",
        r"risk management",
        r"risk factors",
        r"enterprise risks",
        r"material risks",
        r"major risks",
    ]

    def __init__(self):

        self.patterns = [
            re.compile(pattern, re.IGNORECASE)
            for pattern in self.RISK_SECTION_PATTERNS
        ]

    def detect(
        self,
        pages: List[PageContent],
    ) -> List[PageContent]:

        relevant_pages = []

        for page in pages:

            text = page.text.lower()

            if any(
                pattern.search(text)
                for pattern in self.patterns
            ):
                relevant_pages.append(page)

        return relevant_pages