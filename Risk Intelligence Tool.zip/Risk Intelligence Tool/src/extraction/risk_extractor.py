import time
from typing import List, Tuple

from src.ingestion.pdf_reader import PageContent
from src.llm.openai_client import OpenAIRiskClient
from src.models.risk import Risk
from src.utils.metrics import MetricsCollector


class RiskExtractor:

    def __init__(self):
        self.llm = OpenAIRiskClient()

    def extract(
        self,
        chunks: List[str],
        company: str,
        report_year: int,
        metrics: MetricsCollector,
    ) -> List[Risk]:

        all_risks = []

        metrics.chunks = len(chunks)

        for chunk in chunks:

            start = time.perf_counter()

            result, usage = self.llm.extract_risks(
                text=chunk,
                company=company,
                report_year=report_year,
            )

            metrics.llm_generation_time += (
                time.perf_counter() - start
            )

            metrics.llm_calls += 1

            metrics.add_tokens(
                input_tokens=usage["input_tokens"],
                output_tokens=usage["output_tokens"],
                total_tokens=usage["total_tokens"],
            )

            page_numbers = self._extract_page_numbers(chunk)

            for risk in result.risks:

                if risk.page not in page_numbers:

                    if page_numbers:
                        risk.page = page_numbers[0]

                if not risk.section:
                    risk.section = "Principal Risk Disclosure"

                all_risks.append(risk)

        return self._deduplicate(all_risks)

    @staticmethod
    def _extract_page_numbers(text: str) -> List[int]:

        pages = []

        for line in text.splitlines():

            line = line.strip()

            if line.startswith("[PAGE ") and line.endswith("]"):

                try:
                    page_number = int(
                        line.replace("[PAGE ", "")
                        .replace("]", "")
                    )

                    pages.append(page_number)

                except ValueError:
                    continue

        return pages

    def _deduplicate(
        self,
        risks: List[Risk],
    ) -> List[Risk]:

        unique = {}

        for risk in risks:

            key = (
                risk.title
                .strip()
                .lower()
                .replace("-", " ")
            )

            if key not in unique:
                unique[key] = risk

        return list(unique.values())