import os
from typing import Tuple

from dotenv import load_dotenv
from openai import OpenAI

from src.models.risk import RiskReport


load_dotenv()


class OpenAIRiskClient:

    def __init__(self):

        api_key = os.getenv("OPENAI_API_KEY")

        if not api_key:
            raise ValueError(
                "OPENAI_API_KEY is not configured in .env"
            )

        self.model = os.getenv(
            "OPENAI_MODEL",
            "gpt-5.6-luna",
        )

        self.client = OpenAI(api_key=api_key)

    def extract_risks(
        self,
        text: str,
        company: str,
        report_year: int,
    ) -> Tuple[RiskReport, dict]:

        system_prompt = """
You are a corporate risk-intelligence analyst.

Your task is to identify PRINCIPAL RISKS disclosed by a company
in its annual report.

Important rules:

1. Extract only risks explicitly disclosed or clearly described.
2. Do not invent risks.
3. Do not infer risks merely because they are common in the industry.
4. Produce a short meaningful risk title.
5. Description must contain 2-3 sentences.
6. Classify into:
   financial, operational, regulatory, market, climate, cyber,
   supply chain, strategic, people, technology, other
7. Extract mitigation ONLY when explicitly stated.
8. Preserve supporting evidence.
9. Do not invent page numbers.
10. Include a risk only when sufficient evidence exists.
11. Consolidate duplicate descriptions within the supplied context.
12. Return structured data only.
"""

        user_prompt = f"""
Company: {company}
Annual Report Year: {report_year}

Analyze the following annual-report content.

Identify the company's principal risks.

IMPORTANT:
The source contains explicit page markers such as [PAGE 72].
Use those markers to identify the source page.

SOURCE TEXT:

{text}
"""

        response = self.client.responses.parse(
            model=self.model,
            input=[
                {
                    "role": "system",
                    "content": system_prompt,
                },
                {
                    "role": "user",
                    "content": user_prompt,
                },
            ],
            text_format=RiskReport,
        )

        parsed = response.output_parsed

        if parsed is None:
            raise ValueError(
                "OpenAI did not return structured risk data."
            )

        usage = getattr(response, "usage", None)

        usage_data = {
            "input_tokens": getattr(
                usage,
                "input_tokens",
                0,
            )
            if usage
            else 0,
            "output_tokens": getattr(
                usage,
                "output_tokens",
                0,
            )
            if usage
            else 0,
            "total_tokens": getattr(
                usage,
                "total_tokens",
                0,
            )
            if usage
            else 0,
        }

        return parsed, usage_data