import time

from src.extraction.chunker import RiskChunker
from src.extraction.risk_extractor import RiskExtractor
from src.extraction.section_detector import SectionDetector
from src.ingestion.pdf_reader import PDFReader
from src.models.risk import (
    PipelineMetrics,
    PipelineResult,
    RiskReport,
)
from src.utils.metrics import MetricsCollector


class RiskPipeline:

    def __init__(self, pdf_path: str):

        self.reader = PDFReader(pdf_path)
        self.section_detector = SectionDetector()
        self.chunker = RiskChunker(max_chars=12000)
        self.risk_extractor = RiskExtractor()

    def run(
        self,
        company: str,
        report_year: int,
    ) -> PipelineResult:

        metrics = MetricsCollector()
        metrics.start()

        # ----------------------------------------
        # Step 1: PDF extraction
        # ----------------------------------------

        print("Step 1: Reading PDF...")

        start = time.perf_counter()

        pages = self.reader.extract_pages()

        metrics.pdf_read_time = (
            time.perf_counter() - start
        )

        metrics.total_pages = len(pages)

        print(
            f"Extracted {len(pages)} pages "
            f"in {metrics.pdf_read_time:.2f}s"
        )

        # ----------------------------------------
        # Step 2: Risk section detection
        # ----------------------------------------

        print(
            "\nStep 2: Detecting risk-related sections..."
        )

        start = time.perf_counter()

        relevant_pages = self.section_detector.detect(
            pages
        )

        metrics.risk_detection_time = (
            time.perf_counter() - start
        )

        metrics.risk_pages = len(relevant_pages)

        print(
            f"Found {len(relevant_pages)} relevant pages "
            f"in {metrics.risk_detection_time:.2f}s"
        )

        if not relevant_pages:
            raise ValueError(
                "No risk-related sections were detected."
            )

        # ----------------------------------------
        # Step 3: Chunking
        # ----------------------------------------

        print("\nStep 3: Creating page-aware chunks...")

        start = time.perf_counter()

        chunks = self.chunker.create_chunks(
            relevant_pages
        )

        metrics.chunking_time = (
            time.perf_counter() - start
        )

        metrics.chunks = len(chunks)

        print(
            f"Created {len(chunks)} chunks "
            f"in {metrics.chunking_time:.2f}s"
        )

        # ----------------------------------------
        # Step 4: LLM extraction
        # ----------------------------------------

        print("\nStep 4: Extracting principal risks...")

        risks = self.risk_extractor.extract(
            chunks=chunks,
            company=company,
            report_year=report_year,
            metrics=metrics,
        )

        print(
            f"Extracted {len(risks)} risks"
        )

        # ----------------------------------------
        # Step 5: Post-processing
        # ----------------------------------------

        start = time.perf_counter()

        report = RiskReport(
            company=company,
            report_year=report_year,
            risks=risks,
        )

        metrics.post_processing_time = (
            time.perf_counter() - start
        )

        # ----------------------------------------
        # Final metrics
        # ----------------------------------------

        total_time = metrics.finish()

        metrics_model = PipelineMetrics(
            **metrics.as_dict(total_time)
        )

        print("\n" + "=" * 60)
        print("PIPELINE PERFORMANCE")
        print("=" * 60)

        print(
            f"Total time       : "
            f"{metrics_model.total_time_seconds:.2f}s"
        )

        print(
            f"PDF reading      : "
            f"{metrics_model.pdf_read_time_seconds:.2f}s"
        )

        print(
            f"Risk detection   : "
            f"{metrics_model.risk_detection_time_seconds:.2f}s"
        )

        print(
            f"Chunking         : "
            f"{metrics_model.chunking_time_seconds:.2f}s"
        )

        print(
            f"LLM generation   : "
            f"{metrics_model.llm_generation_time_seconds:.2f}s"
        )

        print(
            f"Post processing  : "
            f"{metrics_model.post_processing_time_seconds:.2f}s"
        )

        print("-" * 60)

        print(
            f"Pages            : "
            f"{metrics_model.total_pages}"
        )

        print(
            f"Risk pages       : "
            f"{metrics_model.risk_pages}"
        )

        print(
            f"Chunks           : "
            f"{metrics_model.chunks}"
        )

        print(
            f"LLM calls        : "
            f"{metrics_model.llm_calls}"
        )

        print(
            f"Input tokens     : "
            f"{metrics_model.input_tokens}"
        )

        print(
            f"Output tokens    : "
            f"{metrics_model.output_tokens}"
        )

        print(
            f"Total tokens     : "
            f"{metrics_model.total_tokens}"
        )

        print("=" * 60)

        return PipelineResult(
            report=report,
            metrics=metrics_model,
        )