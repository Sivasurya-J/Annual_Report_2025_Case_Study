from typing import List, Optional
from pydantic import BaseModel, Field


class Risk(BaseModel):
    title: str = Field(description="Short, concise title of the principal risk")
    description: str = Field(description="Two to three sentence description of the risk")
    category: str = Field(
        description=(
            "Risk category such as financial, operational, regulatory, "
            "market, climate, cyber, supply chain, strategic, people"
        )
    )
    section: str = Field(description="Name of the annual report section")
    page: int = Field(description="PDF page number where the risk was found")
    mitigation: Optional[str] = Field(
        default=None,
        description="Any mitigation action explicitly stated by the company",
    )
    evidence: str = Field(
        description="Supporting evidence from the annual report"
    )


class RiskReport(BaseModel):
    company: str
    report_year: int
    risks: List[Risk]


class PipelineMetrics(BaseModel):
    total_time_seconds: float = 0.0
    pdf_read_time_seconds: float = 0.0
    risk_detection_time_seconds: float = 0.0
    chunking_time_seconds: float = 0.0
    llm_generation_time_seconds: float = 0.0
    post_processing_time_seconds: float = 0.0

    total_pages: int = 0
    risk_pages: int = 0
    chunks: int = 0
    llm_calls: int = 0

    input_tokens: int = 0
    output_tokens: int = 0
    total_tokens: int = 0


class PipelineResult(BaseModel):
    report: RiskReport
    metrics: PipelineMetrics