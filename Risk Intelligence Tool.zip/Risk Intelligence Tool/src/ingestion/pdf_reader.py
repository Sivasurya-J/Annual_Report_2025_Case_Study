from pathlib import Path
from typing import List

import fitz
from pydantic import BaseModel


class PageContent(BaseModel):
    page_number: int
    text: str


class PDFReader:

    def __init__(self, pdf_path: str):
        self.pdf_path = Path(pdf_path)

        if not self.pdf_path.exists():
            raise FileNotFoundError(
                f"PDF not found: {self.pdf_path}"
            )

    def extract_pages(self) -> List[PageContent]:

        pages = []

        document = fitz.open(self.pdf_path)

        try:
            for index, page in enumerate(document):

                text = page.get_text("text").strip()

                if not text:
                    continue

                pages.append(
                    PageContent(
                        page_number=index + 1,
                        text=text,
                    )
                )

        finally:
            document.close()

        return pages