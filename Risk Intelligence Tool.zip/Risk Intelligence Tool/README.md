# Vestas Risk Intelligence Pipeline

## Objective

Extract structured principal risks from a corporate annual report.

The pipeline converts:

Annual Report PDF
        ↓
Page-level text
        ↓
Risk section detection
        ↓
LLM risk extraction
        ↓
Pydantic validation
        ↓
Structured JSON
        ↓
Evaluation

## Architecture

The system separates deterministic processing from semantic
understanding.

### Python

Responsible for:

- PDF ingestion
- Page identification
- Section detection
- Page/source tracking
- Output validation
- Evaluation

### OpenAI

Responsible for:

- Risk identification
- Risk title generation
- Risk description
- Risk categorization
- Mitigation extraction

## Running

Create the virtual environment:

python -m venv env

Activate it:

Windows:

env\Scripts\activate

Install dependencies:

pip install -r requirements.txt

Configure `.env`:

OPENAI_API_KEY=your_key
OPENAI_MODEL=your_model

Run:

python scripts/run_pipeline.py

Evaluate:

python evals/evaluate.py

Run tests:

pytest