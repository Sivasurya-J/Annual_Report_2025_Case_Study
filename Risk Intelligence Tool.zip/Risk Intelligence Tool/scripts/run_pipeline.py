import argparse
import json
from pathlib import Path

from src.pipeline.risk_pipeline import RiskPipeline


PDF_PATH = "data/input/VestasAnnualReport2025.pdf"
OUTPUT_PATH = "data/output/vestas_risks.json"


def main():

    parser = argparse.ArgumentParser(
        description="Vestas Risk Intelligence Pipeline"
    )

    parser.add_argument(
        "--company",
        default="Vestas",
    )

    parser.add_argument(
        "--year",
        type=int,
        default=2025,
    )

    args = parser.parse_args()

    pipeline = RiskPipeline(
        pdf_path=PDF_PATH
    )

    result = pipeline.run(
        company=args.company,
        report_year=args.year,
    )

    output_path = Path(OUTPUT_PATH)

    output_path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    with open(
        output_path,
        "w",
        encoding="utf-8",
    ) as file:

        json.dump(
            result.model_dump(),
            file,
            indent=2,
            ensure_ascii=False,
        )

    print(
        f"\nResults written to: {output_path}"
    )

    print(
        f"Total risks: "
        f"{len(result.report.risks)}"
    )


if __name__ == "__main__":
    main()