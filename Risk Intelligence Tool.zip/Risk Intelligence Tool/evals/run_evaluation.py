from evals.evaluate import evaluate
from evals.quality_evaluator import QualityEvaluator


def main():

    print("\nRunning deterministic evaluation...")

    evaluate()

    print(
        "\nRunning relevance and groundedness evaluation..."
    )

    evaluator = QualityEvaluator()

    evaluator.evaluate_all()


if __name__ == "__main__":
    main()