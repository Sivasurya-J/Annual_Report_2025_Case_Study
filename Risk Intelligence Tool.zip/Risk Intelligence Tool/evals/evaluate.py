
import csv
import json
import re
from pathlib import Path
from typing import Dict, List, Optional


GOLDEN_PATH = Path(
    "evals/golden_set.json"
)

RESULT_PATH = Path(
    "data/output/vestas_risks.json"
)

EVALUATION_DIR = Path(
    "data/output/evaluation"
)

DETERMINISTIC_RESULTS_PATH = (
    EVALUATION_DIR / "deterministic_results.csv"
)

DETERMINISTIC_SUMMARY_PATH = (
    EVALUATION_DIR / "deterministic_summary.csv"
)

PAGE_TOLERANCE = 1


def normalize_title(title: str) -> str:
    """
    Normalize a risk title for comparison.
    """

    title = title.lower().strip()

    title = re.sub(
        r"[^a-z0-9\s]",
        " ",
        title,
    )

    title = re.sub(
        r"\s+",
        " ",
        title,
    )

    return title


def titles_match(
    expected_title: str,
    predicted_title: str,
) -> bool:
    """
    Determine whether two risk titles refer to the same risk.

    Exact normalized matching is preferred. A token-based fallback
    handles minor wording differences.
    """

    expected = normalize_title(
        expected_title
    )

    predicted = normalize_title(
        predicted_title
    )

    if expected == predicted:
        return True

    expected_tokens = set(
        expected.split()
    )

    predicted_tokens = set(
        predicted.split()
    )

    if not expected_tokens or not predicted_tokens:
        return False

    overlap = (
        len(
            expected_tokens
            & predicted_tokens
        )
        / len(expected_tokens)
    )

    return overlap >= 0.75


def find_matching_prediction(
    expected_risk: Dict,
    predicted_risks: List[Dict],
) -> Optional[Dict]:

    for index, predicted in enumerate(
        predicted_risks
    ):

        if titles_match(
            expected_risk["title"],
            predicted["title"],
        ):

            return {
                "risk": predicted,
                "position": index + 1,
            }

    return None


def calculate_page_match(
    expected_page: int,
    predicted_page: int,
) -> bool:

    return (
        abs(
            expected_page
            - predicted_page
        )
        <= PAGE_TOLERANCE
    )


def evaluate():

    EVALUATION_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    with open(
        GOLDEN_PATH,
        "r",
        encoding="utf-8",
    ) as file:

        golden_data = json.load(file)

    with open(
        RESULT_PATH,
        "r",
        encoding="utf-8",
    ) as file:

        result_data = json.load(file)

    predicted_risks = (
        result_data["report"]["risks"]
    )

    total_expected = 0
    total_matched = 0
    total_page_matches = 0
    total_exact_page_matches = 0

    query_hits = 0
    reciprocal_ranks = []

    result_rows = []

    for query_data in golden_data:

        query = query_data["query"]

        expected_risks = (
            query_data["expected_risks"]
        )

        total_expected += len(
            expected_risks
        )

        first_match_position = None

        for expected in expected_risks:

            match = find_matching_prediction(
                expected,
                predicted_risks,
            )

            if match:

                predicted = match["risk"]
                position = match["position"]

                risk_match = True

                if first_match_position is None:
                    first_match_position = position

                total_matched += 1

                predicted_page = predicted.get(
                    "page"
                )

                expected_page = expected.get(
                    "page"
                )

                if (
                    predicted_page is not None
                    and expected_page is not None
                ):

                    page_match = calculate_page_match(
                        expected_page,
                        predicted_page,
                    )

                    exact_page_match = (
                        predicted_page
                        == expected_page
                    )

                    if page_match:
                        total_page_matches += 1

                    if exact_page_match:
                        total_exact_page_matches += 1

                else:

                    page_match = False
                    exact_page_match = False
                    predicted_page = ""

                result_rows.append(
                    {
                        "query": query,
                        "expected_risk": expected["title"],
                        "expected_page": expected_page,
                        "predicted_risk": predicted["title"],
                        "predicted_page": predicted_page,
                        "prediction_position": position,
                        "risk_match": "Yes",
                        "page_match": (
                            "Yes"
                            if page_match
                            else "No"
                        ),
                        "exact_page_match": (
                            "Yes"
                            if exact_page_match
                            else "No"
                        ),
                    }
                )

            else:

                result_rows.append(
                    {
                        "query": query,
                        "expected_risk": expected["title"],
                        "expected_page": expected.get(
                            "page",
                            "",
                        ),
                        "predicted_risk": "",
                        "predicted_page": "",
                        "prediction_position": "",
                        "risk_match": "No",
                        "page_match": "No",
                        "exact_page_match": "No",
                    }
                )

        if first_match_position is not None:

            query_hits += 1

            reciprocal_ranks.append(
                1 / first_match_position
            )

        else:

            reciprocal_ranks.append(0)

    number_of_queries = len(
        golden_data
    )

    number_of_predicted = len(
        predicted_risks
    )

    recall = (
        total_matched / total_expected
        if total_expected
        else 0
    )

    precision = (
        total_matched / number_of_predicted
        if number_of_predicted
        else 0
    )

    hit_rate = (
        query_hits / number_of_queries
        if number_of_queries
        else 0
    )

    mrr = (
        sum(reciprocal_ranks)
        / len(reciprocal_ranks)
        if reciprocal_ranks
        else 0
    )

    page_accuracy = (
        total_page_matches / total_matched
        if total_matched
        else 0
    )

    exact_page_accuracy = (
        total_exact_page_matches
        / total_matched
        if total_matched
        else 0
    )

    # ---------------------------------------------------------
    # Write detailed deterministic results
    # ---------------------------------------------------------

    with open(
        DETERMINISTIC_RESULTS_PATH,
        "w",
        newline="",
        encoding="utf-8",
    ) as file:

        fieldnames = [
            "query",
            "expected_risk",
            "expected_page",
            "predicted_risk",
            "predicted_page",
            "prediction_position",
            "risk_match",
            "page_match",
            "exact_page_match",
        ]

        writer = csv.DictWriter(
            file,
            fieldnames=fieldnames,
        )

        writer.writeheader()
        writer.writerows(result_rows)

    # ---------------------------------------------------------
    # Write aggregate summary
    # ---------------------------------------------------------

    summary_rows = [
        {
            "metric": "Recall",
            "value": round(recall, 4),
        },
        {
            "metric": "Precision",
            "value": round(precision, 4),
        },
        {
            "metric": "Query Hit Rate",
            "value": round(hit_rate, 4),
        },
        {
            "metric": "MRR",
            "value": round(mrr, 4),
        },
        {
            "metric": "Page Accuracy",
            "value": round(page_accuracy, 4),
        },
        {
            "metric": "Exact Page Accuracy",
            "value": round(
                exact_page_accuracy,
                4,
            ),
        },
        {
            "metric": "Expected Risks",
            "value": total_expected,
        },
        {
            "metric": "Matched Risks",
            "value": total_matched,
        },
        {
            "metric": "Predicted Risks",
            "value": number_of_predicted,
        },
        {
            "metric": "Queries",
            "value": number_of_queries,
        },
    ]

    with open(
        DETERMINISTIC_SUMMARY_PATH,
        "w",
        newline="",
        encoding="utf-8",
    ) as file:

        writer = csv.DictWriter(
            file,
            fieldnames=[
                "metric",
                "value",
            ],
        )

        writer.writeheader()
        writer.writerows(
            summary_rows
        )

    # ---------------------------------------------------------
    # Terminal output - only high-level confirmation
    # ---------------------------------------------------------

    print(
        "\nDeterministic evaluation completed."
    )

    print(
        f"Results : "
        f"{DETERMINISTIC_RESULTS_PATH}"
    )

    print(
        f"Summary : "
        f"{DETERMINISTIC_SUMMARY_PATH}"
    )

    print(
        "\nMetrics:"
    )

    print(
        f"Recall              : {recall:.2%}"
    )

    print(
        f"Precision           : {precision:.2%}"
    )

    print(
        f"Query Hit Rate      : {hit_rate:.2%}"
    )

    print(
        f"MRR                 : {mrr:.4f}"
    )

    print(
        f"Page Accuracy       : {page_accuracy:.2%}"
    )

    print(
        f"Exact Page Accuracy : "
        f"{exact_page_accuracy:.2%}"
    )

    # ---------------------------------------------------------
    # Evaluation gates
    #
    # Precision is NOT a gate because the current query-based
    # golden set is not exhaustive.
    # ---------------------------------------------------------

    if recall < 0.80:

        raise AssertionError(
            f"Risk recall below 80%: "
            f"{recall:.2%}"
        )

    if page_accuracy < 0.80:

        raise AssertionError(
            f"Page accuracy below 80%: "
            f"{page_accuracy:.2%}"
        )

    print(
        "\nNote: Precision is reported against the "
        "current golden set, but is not used as a "
        "pass/fail gate because the golden set is "
        "not exhaustive."
    )

    return {
        "recall": recall,
        "precision": precision,
        "hit_rate": hit_rate,
        "mrr": mrr,
        "page_accuracy": page_accuracy,
        "exact_page_accuracy": exact_page_accuracy,
    }


if __name__ == "__main__":
    evaluate()

import csv
import json
import os
from pathlib import Path

from dotenv import load_dotenv
from openai import OpenAI


load_dotenv()


RESULT_PATH = Path(
    "data/output/vestas_risks.json"
)

EVALUATION_DIR = Path(
    "data/output/evaluation"
)

QUALITY_RESULTS_PATH = (
    EVALUATION_DIR
    / "quality_evaluation.csv"
)


class QualityEvaluator:

    def __init__(self):

        api_key = os.getenv(
            "OPENAI_API_KEY"
        )

        if not api_key:
            raise ValueError(
                "OPENAI_API_KEY is not configured."
            )

        self.model = os.getenv(
            "OPENAI_MODEL",
            "gpt-5.6-luna",
        )

        self.client = OpenAI(
            api_key=api_key
        )

    def evaluate_risk(
        self,
        risk: dict,
    ) -> dict:

        prompt = f"""
You are evaluating an extracted corporate risk
from an annual report.

Evaluate ONLY the information supplied below.

Risk title:
{risk["title"]}

Description:
{risk["description"]}

Category:
{risk["category"]}

Section:
{risk["section"]}

Page:
{risk["page"]}

Mitigation:
{risk.get("mitigation")}

Evidence:
{risk["evidence"]}

Evaluate the following:

1. Relevance
Is this actually a meaningful corporate risk
supported by the supplied evidence?

2. Groundedness
Are the description, category and mitigation
supported by the supplied evidence?
Penalize unsupported claims or hallucinations.

Give each score from 1 to 5.

Scoring:

5 = Excellent
4 = Strong
3 = Moderate
2 = Weak
1 = Poor

Return ONLY valid JSON:

{{
  "relevance": 1,
  "groundedness": 1,
  "reason": "short explanation"
}}
"""

        response = self.client.responses.create(
            model=self.model,
            input=prompt,
        )

        text = response.output_text.strip()

        try:

            result = json.loads(text)

            return {
                "relevance": int(
                    result.get(
                        "relevance",
                        0,
                    )
                ),
                "groundedness": int(
                    result.get(
                        "groundedness",
                        0,
                    )
                ),
                "reason": result.get(
                    "reason",
                    "",
                ),
            }

        except (
            json.JSONDecodeError,
            ValueError,
            TypeError,
        ):

            return {
                "relevance": 0,
                "groundedness": 0,
                "reason": (
                    "Evaluator returned "
                    "invalid JSON."
                ),
            }

    def evaluate_all(self):

        EVALUATION_DIR.mkdir(
            parents=True,
            exist_ok=True,
        )

        with open(
            RESULT_PATH,
            "r",
            encoding="utf-8",
        ) as file:

            data = json.load(file)

        risks = data["report"]["risks"]

        results = []

        for index, risk in enumerate(
            risks,
            start=1,
        ):

            print(
                f"Evaluating risk "
                f"{index}/{len(risks)}: "
                f"{risk['title']}"
            )

            evaluation = self.evaluate_risk(
                risk
            )

            results.append(
                {
                    "risk_title": risk["title"],
                    "category": risk["category"],
                    "section": risk["section"],
                    "page": risk["page"],
                    "relevance": evaluation[
                        "relevance"
                    ],
                    "groundedness": evaluation[
                        "groundedness"
                    ],
                    "reason": evaluation[
                        "reason"
                    ],
                }
            )

        # -----------------------------------------------------
        # Calculate aggregate scores
        # -----------------------------------------------------

        relevance_scores = [
            item["relevance"]
            for item in results
            if item["relevance"] > 0
        ]

        groundedness_scores = [
            item["groundedness"]
            for item in results
            if item["groundedness"] > 0
        ]

        avg_relevance = (
            sum(relevance_scores)
            / len(relevance_scores)
            if relevance_scores
            else 0
        )

        avg_groundedness = (
            sum(groundedness_scores)
            / len(groundedness_scores)
            if groundedness_scores
            else 0
        )

        # -----------------------------------------------------
        # Add summary row
        # -----------------------------------------------------

        results.append(
            {
                "risk_title": "AVERAGE",
                "category": "",
                "section": "",
                "page": "",
                "relevance": round(
                    avg_relevance,
                    2,
                ),
                "groundedness": round(
                    avg_groundedness,
                    2,
                ),
                "reason": (
                    "Average across all "
                    "evaluated risks."
                ),
            }
        )

        # -----------------------------------------------------
        # Write CSV
        # -----------------------------------------------------

        with open(
            QUALITY_RESULTS_PATH,
            "w",
            newline="",
            encoding="utf-8",
        ) as file:

            fieldnames = [
                "risk_title",
                "category",
                "section",
                "page",
                "relevance",
                "groundedness",
                "reason",
            ]

            writer = csv.DictWriter(
                file,
                fieldnames=fieldnames,
            )

            writer.writeheader()
            writer.writerows(results)

        # -----------------------------------------------------
        # Terminal output - only summary
        # -----------------------------------------------------

        print(
            "\nLLM quality evaluation completed."
        )

        print(
            f"Results : "
            f"{QUALITY_RESULTS_PATH}"
        )

        print(
            f"Average relevance    : "
            f"{avg_relevance:.2f}/5"
        )

        print(
            f"Average groundedness : "
            f"{avg_groundedness:.2f}/5"
        )

        return {
            "average_relevance": avg_relevance,
            "average_groundedness": avg_groundedness,
            "results": results,
        }


if __name__ == "__main__":

    evaluator = QualityEvaluator()
    evaluator.evaluate_all()

