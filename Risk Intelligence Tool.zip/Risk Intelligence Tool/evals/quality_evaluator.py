import json
import os
from pathlib import Path

from dotenv import load_dotenv
from openai import OpenAI


load_dotenv()


RESULT_PATH = Path(
    "data/output/vestas_risks.json"
)


class QualityEvaluator:

    def __init__(self):

        api_key = os.getenv(
            "OPENAI_API_KEY"
        )

        if not api_key:
            raise ValueError(
                "OPENAI_API_KEY is not configured."
            )

        self.model = os.getenv(
            "OPENAI_MODEL",
            "gpt-5.6-luna",
        )

        self.client = OpenAI(
            api_key=api_key
        )

    def evaluate_risk(
        self,
        risk: dict,
    ) -> dict:

        prompt = f"""
Evaluate this extracted corporate risk.

Risk title:
{risk["title"]}

Description:
{risk["description"]}

Mitigation:
{risk.get("mitigation")}

Evidence:
{risk["evidence"]}

Evaluate:

1. relevance:
   Is this actually a meaningful corporate risk?

2. groundedness:
   Are the description and mitigation supported by
   the supplied evidence?

Give scores from 1 to 5.

Return ONLY JSON:

{{
  "relevance": 1,
  "groundedness": 1,
  "reason": "short explanation"
}}
"""

        response = self.client.responses.create(
            model=self.model,
            input=prompt,
        )

        text = response.output_text.strip()

        try:
            return json.loads(text)
        except json.JSONDecodeError:

            return {
                "relevance": 0,
                "groundedness": 0,
                "reason": "Evaluator returned invalid JSON.",
            }

    def evaluate_all(self):

        with open(
            RESULT_PATH,
            "r",
            encoding="utf-8",
        ) as file:

            data = json.load(file)

        risks = data["report"]["risks"]

        results = []

        for risk in risks:

            evaluation = self.evaluate_risk(
                risk
            )

            results.append(
                {
                    "title": risk["title"],
                    **evaluation,
                }
            )

        relevance_scores = [
            item["relevance"]
            for item in results
            if item["relevance"] > 0
        ]

        groundedness_scores = [
            item["groundedness"]
            for item in results
            if item["groundedness"] > 0
        ]

        avg_relevance = (
            sum(relevance_scores)
            / len(relevance_scores)
            if relevance_scores
            else 0
        )

        avg_groundedness = (
            sum(groundedness_scores)
            / len(groundedness_scores)
            if groundedness_scores
            else 0
        )

        print("\n")
        print("=" * 60)
        print("LLM QUALITY EVALUATION")
        print("=" * 60)

        print(
            f"Average relevance    : "
            f"{avg_relevance:.2f}/5"
        )

        print(
            f"Average groundedness : "
            f"{avg_groundedness:.2f}/5"
        )

        print("-" * 60)

        for result in results:

            print(
                f"{result['title']}"
            )

            print(
                f"  Relevance    : "
                f"{result['relevance']}/5"
            )

            print(
                f"  Groundedness : "
                f"{result['groundedness']}/5"
            )

        print("=" * 60)

        return {
            "average_relevance": avg_relevance,
            "average_groundedness": avg_groundedness,
            "results": results,
        }


if __name__ == "__main__":

    evaluator = QualityEvaluator()
    evaluator.evaluate_all()