**Failure Case 1** — Over-selection of Risk Sections



**Expected:**
Only the three explicitly identified "Main risks".



**Observed:**
The section detector selected additional financial,
sustainability, cybersecurity, and workforce-risk pages.



**Impact:**
The LLM extracted many legitimate risks that were outside
the intended principal-risk scope.



**Root Cause:**
Keyword-based section detection was too broad.



**Fix:**
Detect the explicit "Main risks" section and its boundaries
rather than treating every page containing the word "risk"
as part of the principal-risk section.



**Evaluation Signal:**
Precision decreased because the system returned risks
outside the intended principal-risk scope.

